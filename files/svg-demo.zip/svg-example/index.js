/**
 * Created by Faiz on 6/24/2015.
 */
var connector = new Y.WebRTC("yjs-svg", { debug: false }),
    y = new Y(connector),
    id = 0,
    $undo = $("#undo"),
    $redo = $("#redo"),
    $addRect = $("#addRect");

$undo.on('click', function(e) {
    var $shared_canvas = $("#shared_canvas"),
        $undo_actions = $("#undo_actions"),
        $redo_actions = $("#redo_actions"),
        $li,
        action,
        obj;

    if (y.val("undo_list").val().length !== 0) { //can only undo when got action in list
        //get the last action so that we can undo that action
        action = y.val("undo_list").val(y.val("undo_list").val().length - 1);
        obj = JSON.parse(action);

        //don't forget to delete the last undo action retrieved
        y.val("undo_list").delete(y.val("undo_list").val().length - 1);

        $li = $('<li></li>');
        if (obj.shapeAdded !== undefined) {
            //1. Remove the last shape added
            $shared_canvas.children()[$shared_canvas.children().length - 1].remove();
            //2. Update our undo redo list
            action = $($undo_actions.children()[$undo_actions.children().length - 1]).text();
            $undo_actions.children()[$undo_actions.children().length - 1].remove();
            $li.text(action);
            $redo_actions.append($li);
            y.val("redo_list").push(JSON.stringify(obj));
        }
    }
});

$redo.on('click', function(e) {
    var $shared_canvas = $("#shared_canvas"),
        $undo_actions = $("#undo_actions"),
        $redo_actions = $("#redo_actions"),
        $li,
        $dom,
        action,
        obj;

    if (y.val("redo_list").val().length !== 0) { //can only redo when got action in list
        //get the last action so that we can redo that action
        action = y.val("redo_list").val(y.val("redo_list").val().length - 1);
        obj = JSON.parse(action);

        //don't forget to delete the last redo action retrieved
        y.val("redo_list").delete(y.val("redo_list").val().length - 1);

        $li = $('<li></li>');
        if (obj.shapeAdded !== undefined) {
            //1. Re-add the spape
            $dom = $(new DOMParser().parseFromString(obj.shapeAdded, "image/svg+xml").documentElement);
            $dom.attr('xmlns', null); //remember to remove the xmlns
            $shared_canvas.append($dom);
            //2. Update our undo redo list
            action = $($redo_actions.children()[$redo_actions.children().length - 1]).text();
            $redo_actions.children()[$redo_actions.children().length - 1].remove();
            $li.text(action);
            $undo_actions.append($li);
            y.val("undo_list").push(JSON.stringify(obj));
        }
    }
});

$addRect.on('click', function(e) {
    var $shared_canvas = $("#shared_canvas"),
        $group = $(document.createElementNS('http://www.w3.org/2000/svg', 'g')),
        $rect = $(document.createElementNS('http://www.w3.org/2000/svg', 'rect'));

    $group.attr({ id: id });
    $rect.attr({
        x: Math.floor(Math.random() * (1000 - 30)) + 30,
        y: Math.floor(Math.random() * (100 - 30)) + 30,
        width: 30,
        height: 30,
        opacity: 0.5,
        fill: '#'+Math.floor(Math.random()*16777215).toString(16)
    }).appendTo($group);
    id++; //update the id
    $shared_canvas.append($group);

    var serialized = new XMLSerializer().serializeToString($group[0]),
        regex = /xmlns="http:\/\/www\.w3\.org\/2000\/svg"/g,
        $undo_actions = $("#undo_actions"),
        obj = {};

    //push into undo list
    //must not remove the xmlns created by XMLSerializer, needed by the DOMParser to parse correctly as SVGElement
    obj.shapeAdded = serialized;
    y.val("undo_list").push(JSON.stringify(obj));

    //write out the list so that we can see our actions
    var $li = $('<li></li>');
    $li.text('{"shapeAdded":"' + serialized.replace(regex, '') + '"}');
    $undo_actions.append($li);
});

window.onload = function() {
    y.observe(function(events) {
        for(var i = 0; i < events.length; i++) {
            var event = events[i];
            //**************Problem 1: How to show the synchronized # of connected users?*********************
            if (event.name === "user_num" && event.type !== "delete") {
                y.val("user_num").getDom().innerText = "" + Object.keys(connector.connections).length;
                $('#user_num').replaceWith(y.val("user_num").getDom());
            }
            //************************************************************************************************
            if (event.name === "shared_canvas" && event.type !== "delete") {
                $('#shared_canvas').replaceWith(y.val("shared_canvas").getDom()); //getDom is the 2-way binding
            }
            if (event.name === "undo_actions" && event.type !== "delete") {
                $('#undo_actions').replaceWith(y.val("undo_actions").getDom());
            }
            if (event.name === "redo_actions" && event.type !== "delete") {
                $('#redo_actions').replaceWith(y.val("redo_actions").getDom());
            }
        }
    });

    connector.whenSynced(function() { //do when first time sync
        if (document.getElementById("uid").innerText === "NOT CONNECTED") {
            document.getElementById("uid").innerText = connector.user_id;
        }

        //**************Problem 1: How to show the synchronized # of connected users?*********************
        if (y.val("user_num") === undefined) {
            document.getElementById("user_num").innerText = "" + Object.keys(connector.connections).length;
            y.val("user_num", new Y.Xml.Element($("#user_num")[0]));
        }
        else {
            document.getElementById("user_num").innerText = "" + Object.keys(connector.connections).length;
        }
        //************************************************************************************************

        //our svg canvas
        if (y.val("shared_canvas") === undefined) { y.val("shared_canvas", new Y.Xml.Element($("#shared_canvas")[0])); }

        //undo
        if (y.val("undo_actions") === undefined) { y.val("undo_actions", new Y.Xml.Element($("#undo_actions")[0])); }
        if (y.val("undo_list") === undefined) { y.val("undo_list", new Y.List()); }

        //redo
        if (y.val("redo_actions") === undefined) { y.val("redo_actions", new Y.Xml.Element($("#redo_actions")[0])); }
        if (y.val("redo_list") === undefined) { y.val("redo_list", new Y.List()); }
    });
};